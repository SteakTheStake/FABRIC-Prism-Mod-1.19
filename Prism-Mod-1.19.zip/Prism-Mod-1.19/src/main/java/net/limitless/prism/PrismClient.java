package net.limitless.prism;

import net.fabricmc.api.ClientModInitializer;

public class PrismClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
